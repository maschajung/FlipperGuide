let daten=[];const l=document.getElementById('list'),d=document.getElementById('detail'),s=document.getElementById('search');
fetch('daten.json').then(r=>r.json()).then(j=>{daten=j;fill();});
function fill(f=''){l.innerHTML='';daten.filter(x=>x.Flipper.toLowerCase().includes(f.toLowerCase())).forEach(x=>{let o=document.createElement('option');o.value=x.Flipper;o.textContent=x.Flipper;l.appendChild(o)});show();}
function show(){let x=daten.find(a=>a.Flipper===l.value)||daten[0];if(!x)return;d.innerHTML='';for(const k in x){let c=document.createElement('div');c.className='card';c.innerHTML='<b>'+k+'</b><br>'+x[k];d.appendChild(c)}}
s.oninput=()=>fill(s.value);l.onchange=show;