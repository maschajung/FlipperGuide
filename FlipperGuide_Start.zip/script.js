document.getElementById('suche').addEventListener('input',()=>{
// Version 1 – Funktion folgt im nächsten Schritt.
});